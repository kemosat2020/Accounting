import React, { useEffect } from 'react';
import { Invoice, AppData } from '../types';

interface InvoicePreviewProps {
  invoice: Invoice | null;
  settings: AppData['settings'];
}

const InvoicePreview: React.FC<InvoicePreviewProps> = ({ invoice, settings }) => {
  useEffect(() => {
    if (invoice) {
        // Dummy barcode generation - in a real app, use a library
        const generateBarcode = (selector: string, text: string) => {
            const element = document.getElementById(selector);
            if (!element) return;
            element.innerHTML = ''; // Clear previous barcode
            // Simple visual pattern based on invoice number characters
            for (let i = 0; i < 40; i++) { // Generate a fixed number of bars
                const charCode = text.charCodeAt(i % text.length);
                const bar = document.createElementNS("http://www.w3.org/2000/svg", "rect");
                bar.setAttribute('x', String(i * 3));
                bar.setAttribute('y', '0');
                bar.setAttribute('width', String(charCode % 2 === 0 ? 2.5 : 1.5)); // Vary width based on char code
                bar.setAttribute('height', '100%');
                bar.setAttribute('fill', '#000');
                element.appendChild(bar);
            }
        };
        generateBarcode('barcode', String(invoice.invoiceNumber));
    }
  }, [invoice]);

  if (!invoice) return <div className="p-4">لا توجد بيانات فاتورة لعرضها.</div>;
  
  const renderLine = () => <div className="border-t border-dashed border-black my-1"></div>;

  // This outer div is for centering in the modal view, it will be hidden on print.
  return (
    <div className="flex justify-center bg-gray-200 py-4">
      <div id="printable-invoice" className="font-mono bg-white text-black p-2 max-w-sm w-full text-[10pt] leading-snug">
        <div className="text-center">
          {settings.companyLogo && <img src={settings.companyLogo} alt="Company Logo" className="mx-auto max-h-20 mb-2" />}
          <p className="font-bold text-sm">{settings.companyName}</p>
          <p className="text-xs">{settings.companyAddress}</p>
          <p className="text-xs">الهاتف: {settings.companyPhone}</p>
          <p className="text-xs">الرقم الضريبي: {settings.vatNumber}</p>
        </div>

        {renderLine()}

        <div className="text-xs space-y-0.5">
          <div className="flex justify-between"><span>رقم الفاتورة:</span><span>{invoice.invoiceNumber}</span></div>
          <div className="flex justify-between"><span>التاريخ:</span><span>{new Date(invoice.date).toLocaleDateString('ar-EG')}</span></div>
          <div className="flex justify-between"><span>الوقت:</span><span>{new Date(invoice.date).toLocaleTimeString('ar-EG')}</span></div>
          <div className="flex justify-between"><span>العميل:</span><span>{invoice.customerName}</span></div>
        </div>

        {renderLine()}

        <div>
          <div className="grid grid-cols-12 text-xs font-bold">
              <div className="col-span-5">الصنف</div>
              <div className="col-span-2 text-center">الكمية</div>
              <div className="col-span-2 text-center">السعر</div>
              <div className="col-span-3 text-left">الإجمالي</div>
          </div>
          {renderLine()}
          {invoice.items.map((item) => (
            <div key={item.productId} className="grid grid-cols-12 text-xs my-1">
              <div className="col-span-5">{item.name}</div>
              <div className="col-span-2 text-center">{item.quantity}</div>
              <div className="col-span-2 text-center">{item.price.toFixed(2)}</div>
              <div className="col-span-3 text-left">{(item.quantity * item.price).toFixed(2)}</div>
            </div>
          ))}
        </div>
        
        {renderLine()}

        <div className="text-xs space-y-1">
          <div className="flex justify-between">
              <span>الإجمالي الفرعي:</span>
              <span>{invoice.subtotal.toFixed(2)}</span>
          </div>
          {invoice.discount > 0 && 
              <div className="flex justify-between">
                  <span>الخصم:</span>
                  <span>- {invoice.discount.toFixed(2)}</span>
              </div>
          }
          <div className="flex justify-between">
              <span>الضريبة ({settings.taxRate}%):</span>
              <span>{invoice.tax.toFixed(2)}</span>
          </div>
          {renderLine()}
          <div className="flex justify-between font-bold text-sm">
              <span>المجموع الإجمالي:</span>
              <span>{invoice.total.toFixed(2)} {settings.currencySymbol}</span>
          </div>
        </div>
        
        {renderLine()}

        <div className="text-center text-xs mt-2">
          <p>شكراً لتسوقكم معنا!</p>
          <svg id="barcode" className="h-10 w-full mx-auto mt-2"></svg>
        </div>
      </div>
    </div>
  );
};

export default InvoicePreview;