import React, { useState, useEffect, useMemo } from 'react';
import { Invoice, Customer, Product, InvoiceItem, AppData } from '../types';
import { PrintIcon, DeleteIcon } from './icons';
import InvoicePreview from './InvoicePreview';

type ModalMode = 'create' | 'edit' | 'view';

interface InvoiceModalProps {
  isOpen: boolean;
  onClose: () => void;
  mode: ModalMode;
  invoiceData: Invoice | null;
  customers: Customer[];
  products: Product[];
  settings: AppData['settings'];
  onSave: (invoice: Invoice) => void;
  lastInvoiceNumber: number;
}

const InvoiceModal: React.FC<InvoiceModalProps> = ({ isOpen, onClose, mode, invoiceData, customers, products, settings, onSave, lastInvoiceNumber }) => {
  const [invoice, setInvoice] = useState<Partial<Invoice>>({});
  const [productSearch, setProductSearch] = useState('');
  const [filteredProducts, setFilteredProducts] = useState<Product[]>([]);

  const initialInvoiceState = useMemo(() => {
    return mode === 'create'
      ? {
          id: `inv_${Date.now()}`,
          invoiceNumber: lastInvoiceNumber + 1,
          customerId: customers.find(c => c.name === 'عميل نقدي')?.id || '',
          customerName: 'عميل نقدي',
          items: [],
          discount: 0,
          date: new Date().toISOString(),
        }
      : invoiceData;
  }, [mode, invoiceData, lastInvoiceNumber, customers]);

  useEffect(() => {
    if (isOpen) {
        setInvoice(initialInvoiceState || {});
    }
  }, [isOpen, initialInvoiceState]);

  useEffect(() => {
    if (productSearch) {
      setFilteredProducts(
        products.filter(p => p.name.toLowerCase().includes(productSearch.toLowerCase()))
      );
    } else {
      setFilteredProducts([]);
    }
  }, [productSearch, products]);

  useEffect(() => {
    if (mode !== 'view') {
        const subtotal = invoice.items?.reduce((acc, item) => acc + item.price * item.quantity, 0) || 0;
        const tax = (subtotal - (invoice.discount || 0)) * (settings.taxRate / 100);
        const total = subtotal - (invoice.discount || 0) + tax;
        setInvoice(prev => ({ ...prev, subtotal, tax, total }));
    }
  }, [invoice.items, invoice.discount, settings.taxRate, mode]);

  if (!isOpen) return null;

  const handleCustomerChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const customerId = e.target.value;
    const customer = customers.find(c => c.id === customerId);
    if(customer) {
        setInvoice(prev => ({ ...prev, customerId: customer.id, customerName: customer.name }));
    }
  };

  const handleAddItem = (product: Product) => {
    setProductSearch('');
    setFilteredProducts([]);
    
    const existingItem = invoice.items?.find(item => item.productId === product.id);
    if(existingItem) {
        // Increase quantity if item already exists
        handleItemQuantityChange(product.id, existingItem.quantity + 1);
    } else {
        // Add new item
        const newItem: InvoiceItem = {
            productId: product.id,
            name: product.name,
            quantity: 1,
            price: product.price
        };
        setInvoice(prev => ({...prev, items: [...(prev.items || []), newItem]}));
    }
  };

  const handleRemoveItem = (productId: string) => {
    setInvoice(prev => ({...prev, items: prev.items?.filter(item => item.productId !== productId)}));
  };

  const handleItemQuantityChange = (productId: string, quantity: number) => {
    const product = products.find(p => p.id === productId);
    const originalItem = invoiceData?.items.find(i => i.productId === productId);
    const maxQuantity = product ? product.quantity + (originalItem?.quantity || 0) : 0;

    if (quantity > 0 && quantity <= maxQuantity) {
        setInvoice(prev => ({
            ...prev,
            items: prev.items?.map(item => 
                item.productId === productId ? { ...item, quantity } : item
            )
        }));
    } else if (quantity > maxQuantity) {
        alert(`لا يمكن تجاوز الكمية المتاحة في المخزون: ${maxQuantity}`);
    }
  };
  
  const handleDiscountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      const discount = parseFloat(e.target.value) || 0;
      setInvoice(prev => ({...prev, discount}));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (invoice.items && invoice.items.length > 0) {
        onSave(invoice as Invoice);
    } else {
        alert('يجب إضافة منتج واحد على الأقل إلى الفاتورة.');
    }
  };

  const handlePrint = () => {
    window.print();
  };

  const isForm = mode === 'create' || mode === 'edit';
  const title = mode === 'create' ? 'فاتورة جديدة' : mode === 'edit' ? 'تعديل الفاتورة' : `تفاصيل الفاتورة #${invoiceData?.invoiceNumber}`;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex justify-center items-center" onClick={onClose}>
      <div className="bg-white rounded-lg shadow-xl w-full max-w-4xl max-h-[90vh] flex flex-col" onClick={e => e.stopPropagation()}>
        <header className="px-6 py-4 border-b flex justify-between items-center no-print">
          <h2 className="text-xl font-bold text-gray-800">{title}</h2>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-800 text-3xl">&times;</button>
        </header>
        
        <main className="p-6 overflow-y-auto flex-1">
          {isForm ? (
            <form onSubmit={handleSubmit}>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-4">
                     <div>
                        <label htmlFor="customer" className="block text-sm font-medium text-gray-700 mb-1">العميل</label>
                        <select id="customer" value={invoice.customerId || ''} onChange={handleCustomerChange} className="w-full p-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500">
                           {customers.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                        </select>
                    </div>
                     <div>
                        <label htmlFor="date" className="block text-sm font-medium text-gray-700 mb-1">التاريخ</label>
                        <input type="date" id="date" value={new Date(invoice.date || Date.now()).toISOString().split('T')[0]} onChange={e => setInvoice(prev => ({...prev, date: new Date(e.target.value).toISOString()}))} className="w-full p-2 border border-gray-300 rounded-md shadow-sm"/>
                    </div>
                </div>

                <div className="relative mb-4">
                    <label htmlFor="productSearch" className="block text-sm font-medium text-gray-700 mb-1">إضافة منتج</label>
                    <input 
                        type="text" 
                        id="productSearch"
                        placeholder="ابحث عن منتج بالاسم أو الباركود..."
                        value={productSearch}
                        onChange={e => setProductSearch(e.target.value)}
                        className="w-full p-2 border border-gray-300 rounded-md shadow-sm"
                    />
                    {filteredProducts.length > 0 && (
                        <ul className="absolute z-10 w-full bg-white border border-gray-300 rounded-md mt-1 max-h-40 overflow-y-auto shadow-lg">
                           {filteredProducts.map(p => (
                               <li key={p.id} onClick={() => handleAddItem(p)} className="p-2 cursor-pointer hover:bg-gray-100">
                                   {p.name} ({p.quantity} متاح) - {p.price.toFixed(2)}{settings.currencySymbol}
                               </li>
                           ))}
                        </ul>
                    )}
                </div>

                <div className="mt-6 border rounded-lg overflow-hidden">
                    <table className="min-w-full">
                        <thead className="bg-gray-50">
                            <tr>
                                <th className="px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">المنتج</th>
                                <th className="px-4 py-2 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">الكمية</th>
                                <th className="px-4 py-2 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">السعر</th>
                                <th className="px-4 py-2 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">الإجمالي</th>
                                <th className="px-4 py-2 text-center text-xs font-medium text-gray-500 uppercase tracking-wider"></th>
                            </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-gray-200">
                            {invoice.items?.map(item => (
                                <tr key={item.productId}>
                                    <td className="px-4 py-2 whitespace-nowrap">{item.name}</td>
                                    <td className="px-4 py-2"><input type="number" min="1" value={item.quantity} onChange={e => handleItemQuantityChange(item.productId, parseInt(e.target.value) || 1)} className="w-20 text-center border-gray-300 rounded-md"/></td>
                                    <td className="px-4 py-2 text-center">{item.price.toFixed(2)}</td>
                                    <td className="px-4 py-2 text-center">{(item.price * item.quantity).toFixed(2)}</td>
                                    <td className="px-4 py-2 text-center">
                                        <button type="button" onClick={() => handleRemoveItem(item.productId)} className="text-red-500 hover:text-red-700"><DeleteIcon /></button>
                                    </td>
                                </tr>
                            ))}
                            {(!invoice.items || invoice.items.length === 0) && (
                                <tr><td colSpan={5} className="text-center p-4 text-gray-500">لم يتم إضافة أي منتجات</td></tr>
                            )}
                        </tbody>
                    </table>
                </div>

                <div className="mt-6 flex justify-end">
                    <div className="w-full max-w-sm space-y-2 text-gray-700">
                        <div className="flex justify-between"><span>الإجمالي الفرعي:</span><span>{invoice.subtotal?.toFixed(2) || '0.00'} {settings.currencySymbol}</span></div>
                        <div className="flex justify-between items-center">
                           <span>خصم:</span>
                           <input type="number" value={invoice.discount || ''} onChange={handleDiscountChange} className="w-24 p-1 text-left border rounded-md" />
                        </div>
                        <div className="flex justify-between"><span>الضريبة ({settings.taxRate}%):</span><span>{invoice.tax?.toFixed(2) || '0.00'} {settings.currencySymbol}</span></div>
                        <div className="flex justify-between font-bold text-lg border-t pt-2 mt-2"><span>المجموع الإجمالي:</span><span>{invoice.total?.toFixed(2) || '0.00'} {settings.currencySymbol}</span></div>
                    </div>
                </div>

            </form>
          ) : (
             <InvoicePreview invoice={invoiceData} settings={settings} />
          )}
        </main>
        
        <footer className="px-6 py-4 bg-gray-50 border-t flex justify-end items-center space-x-4 space-x-reverse no-print">
           {mode === 'view' && (
             <button onClick={handlePrint} className="bg-gray-600 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded flex items-center">
                <PrintIcon /> طباعة
             </button>
           )}
           {isForm && (
            <button type="submit" onClick={handleSubmit} className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
              {mode === 'create' ? 'إنشاء الفاتورة' : 'حفظ التعديلات'}
            </button>
           )}
          <button onClick={onClose} className="bg-gray-200 hover:bg-gray-300 text-gray-800 font-bold py-2 px-4 rounded">إغلاق</button>
        </footer>
      </div>
    </div>
  );
};

export default InvoiceModal;