import React, { useState, useEffect } from 'react';
import { useLocalStorage } from './hooks/useLocalStorage';
import { AppData, Product, Customer, Invoice, InvoiceItem } from './types';
import Login from './components/Login';
import InvoiceModal from './components/InvoiceModal';
import {
  DashboardIcon,
  InvoicingIcon,
  ProductsIcon,
  CustomersIcon,
  ReportsIcon,
  SettingsIcon,
  PlusIcon,
  EditIcon,
  DeleteIcon,
  ViewIcon,
  LogoutIcon,
} from './components/icons';

// Some initial data to get started
const initialData: AppData = {
  products: [
    { id: '1', name: 'لابتوب', category: 'إلكترونيات', price: 1200, cost: 800, quantity: 50, barcode: '123456789012', commission: 50 },
    { id: '2', name: 'لوحة مفاتيح', category: 'إلكترونيات', price: 75, cost: 40, quantity: 150, barcode: '123456789013', commission: 5 },
    { id: '3', name: 'فأرة', category: 'إلكترونيات', price: 25, cost: 10, quantity: 200, barcode: '123456789014', commission: 2 },
    { id: '4', name: 'كاميرا ويب', category: 'إلكترونيات', price: 45, cost: 20, quantity: 8, barcode: '123456789015', commission: 3 },
  ],
  customers: [
    { id: '1', name: 'جون دو', phone: '123-456-7890', email: 'john@example.com', points: 150 },
    { id: '2', name: 'جين سميث', phone: '098-765-4321', email: 'jane@example.com', points: 300 },
     { id: '3', name: 'عميل نقدي', phone: '', email: '', points: 0 },
  ],
  invoices: [
    {
      id: '1', invoiceNumber: 1001, customerId: '1', customerName: 'جون دو', items: [
        { productId: '1', name: 'لابتوب', quantity: 1, price: 1200 }
      ], subtotal: 1200, tax: 96, discount: 0, total: 1296, date: new Date().toISOString()
    }
  ],
  settings: {
    taxRate: 8,
    pointsPerCurrency: 1,
    currencySymbol: 'ر.س',
    lowStockThreshold: 10,
    companyName: 'اسم شركتك',
    companyAddress: '123 الشارع الرئيسي، المدينة',
    companyPhone: '555-123-4567',
    vatNumber: '123456789',
    companyLogo: '', // Initially empty
  },
};

// Placeholder components for different sections
const Dashboard = ({ data }: { data: AppData }) => {
    const lowStockProducts = data.products.filter(
        p => p.quantity <= data.settings.lowStockThreshold
    );
    return (
        <div>
            <h1 className="text-3xl font-bold mb-6">لوحة التحكم</h1>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <div className="bg-white p-6 rounded-lg shadow">
                    <h2 className="text-xl font-semibold text-gray-700">إجمالي المنتجات</h2>
                    <p className="text-3xl font-bold mt-2">{data.products.length}</p>
                </div>
                <div className="bg-white p-6 rounded-lg shadow">
                    <h2 className="text-xl font-semibold text-gray-700">إجمالي العملاء</h2>
                    <p className="text-3xl font-bold mt-2">{data.customers.length}</p>
                </div>
                <div className="bg-white p-6 rounded-lg shadow">
                    <h2 className="text-xl font-semibold text-gray-700">إجمالي الفواتير</h2>
                    <p className="text-3xl font-bold mt-2">{data.invoices.length}</p>
                </div>
                <div className="bg-white p-6 rounded-lg shadow">
                    <h2 className="text-xl font-semibold text-gray-700">إجمالي الإيرادات</h2>
                    <p className="text-3xl font-bold mt-2">{data.invoices.reduce((acc, inv) => acc + inv.total, 0).toFixed(2)}{data.settings.currencySymbol}</p>
                </div>
                <div className="bg-white p-6 rounded-lg shadow">
                    <h2 className="text-xl font-semibold text-gray-700">منتجات قاربت على النفاد</h2>
                    <p className={`text-3xl font-bold mt-2 ${lowStockProducts.length > 0 ? 'text-red-500' : ''}`}>{lowStockProducts.length}</p>
                </div>
            </div>
            {lowStockProducts.length > 0 && (
                <div className="mt-8 bg-white p-6 rounded-lg shadow">
                    <h2 className="text-xl font-semibold text-gray-700 mb-4">تنبيهات المخزون المنخفض</h2>
                    <div className="overflow-x-auto">
                        <table className="w-full text-sm text-left text-gray-500">
                            <thead className="text-xs text-gray-700 uppercase bg-gray-50">
                                <tr>
                                    <th scope="col" className="px-6 py-3">اسم المنتج</th>
                                    <th scope="col" className="px-6 py-3">الكمية المتبقية</th>
                                    <th scope="col" className="px-6 py-3">حد المخزون</th>
                                </tr>
                            </thead>
                            <tbody>
                                {lowStockProducts.map(p => (
                                    <tr key={p.id} className="bg-white border-b hover:bg-gray-50">
                                        <td className="px-6 py-4 font-medium text-gray-900 whitespace-nowrap">{p.name}</td>
                                        <td className="px-6 py-4 text-red-600 font-bold">{p.quantity}</td>
                                        <td className="px-6 py-4">{data.settings.lowStockThreshold}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
            )}
        </div>
    );
};

const Products = ({ products, settings }: { products: Product[], settings: AppData['settings'] }) => (
  <div>
    <div className="flex justify-between items-center mb-6">
      <h1 className="text-3xl font-bold">المنتجات</h1>
      <button className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded flex items-center">
        <PlusIcon /> إضافة منتج
      </button>
    </div>
    <div className="bg-white shadow-md rounded my-6 overflow-x-auto">
        <table className="min-w-max w-full table-auto">
            <thead>
                <tr className="bg-gray-200 text-gray-600 uppercase text-sm leading-normal">
                    <th className="py-3 px-6 text-right">اسم المنتج</th>
                    <th className="py-3 px-6 text-right">التصنيف</th>
                    <th className="py-3 px-6 text-center">السعر</th>
                    <th className="py-3 px-6 text-center">الكمية</th>
                    <th className="py-3 px-6 text-center">إجراءات</th>
                </tr>
            </thead>
            <tbody className="text-gray-600 text-sm font-light">
                {products.map(product => (
                    <tr key={product.id} className="border-b border-gray-200 hover:bg-gray-100">
                        <td className="py-3 px-6 text-right whitespace-nowrap">{product.name}</td>
                        <td className="py-3 px-6 text-right">{product.category}</td>
                        <td className="py-3 px-6 text-center">{product.price.toFixed(2)}{settings.currencySymbol}</td>
                        <td className={`py-3 px-6 text-center ${product.quantity <= settings.lowStockThreshold ? 'text-red-500 font-bold' : ''}`}>{product.quantity}</td>
                        <td className="py-3 px-6 text-center">
                            <div className="flex item-center justify-center">
                                <button className="w-4 mr-2 transform hover:text-purple-500 hover:scale-110"><EditIcon /></button>
                                <button className="w-4 mr-2 transform hover:text-purple-500 hover:scale-110"><DeleteIcon /></button>
                            </div>
                        </td>
                    </tr>
                ))}
            </tbody>
        </table>
    </div>
  </div>
);

const Customers = ({ customers }: { customers: Customer[] }) => (
  <div>
    <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">العملاء</h1>
        <button className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded flex items-center">
            <PlusIcon /> إضافة عميل
        </button>
    </div>
    <div className="bg-white shadow-md rounded my-6 overflow-x-auto">
        <table className="min-w-max w-full table-auto">
            <thead>
                <tr className="bg-gray-200 text-gray-600 uppercase text-sm leading-normal">
                    <th className="py-3 px-6 text-right">الاسم</th>
                    <th className="py-3 px-6 text-right">البريد الإلكتروني</th>
                    <th className="py-3 px-6 text-center">الهاتف</th>
                    <th className="py-3 px-6 text-center">النقاط</th>
                    <th className="py-3 px-6 text-center">إجراءات</th>
                </tr>
            </thead>
            <tbody className="text-gray-600 text-sm font-light">
                {customers.map(customer => (
                    <tr key={customer.id} className="border-b border-gray-200 hover:bg-gray-100">
                        <td className="py-3 px-6 text-right whitespace-nowrap">{customer.name}</td>
                        <td className="py-3 px-6 text-right">{customer.email}</td>
                        <td className="py-3 px-6 text-center">{customer.phone}</td>
                        <td className="py-3 px-6 text-center">{customer.points}</td>
                         <td className="py-3 px-6 text-center">
                            <div className="flex item-center justify-center">
                                <button className="w-4 mr-2 transform hover:text-purple-500 hover:scale-110"><EditIcon /></button>
                                <button className="w-4 mr-2 transform hover:text-purple-500 hover:scale-110"><DeleteIcon /></button>
                            </div>
                        </td>
                    </tr>
                ))}
            </tbody>
        </table>
    </div>
  </div>
);

const Invoicing = ({ invoices, settings, onAddNew, onEdit, onView, onDelete }: { invoices: Invoice[], settings: AppData['settings'], onAddNew: () => void, onEdit: (invoice: Invoice) => void, onView: (invoice: Invoice) => void, onDelete: (invoiceId: string) => void }) => (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">الفواتير</h1>
        <button onClick={onAddNew} className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded flex items-center">
          <PlusIcon /> إنشاء فاتورة
        </button>
      </div>
      <div className="bg-white shadow-md rounded my-6 overflow-x-auto">
          <table className="min-w-max w-full table-auto">
              <thead>
                  <tr className="bg-gray-200 text-gray-600 uppercase text-sm leading-normal">
                      <th className="py-3 px-6 text-right">رقم الفاتورة</th>
                      <th className="py-3 px-6 text-right">العميل</th>
                      <th className="py-3 px-6 text-center">التاريخ</th>
                      <th className="py-3 px-6 text-center">الإجمالي</th>
                      <th className="py-3 px-6 text-center">إجراءات</th>
                  </tr>
              </thead>
              <tbody className="text-gray-600 text-sm font-light">
                  {invoices.map(invoice => (
                      <tr key={invoice.id} className="border-b border-gray-200 hover:bg-gray-100">
                          <td className="py-3 px-6 text-right whitespace-nowrap">#{invoice.invoiceNumber}</td>
                          <td className="py-3 px-6 text-right">{invoice.customerName}</td>
                          <td className="py-3 px-6 text-center">{new Date(invoice.date).toLocaleDateString()}</td>
                          <td className="py-3 px-6 text-center">{invoice.total.toFixed(2)}{settings.currencySymbol}</td>
                          <td className="py-3 px-6 text-center">
                              <div className="flex item-center justify-center">
                                  <button onClick={() => onView(invoice)} className="w-5 mr-2 transform hover:text-purple-500 hover:scale-110"><ViewIcon /></button>
                                  <button onClick={() => onEdit(invoice)} className="w-5 mr-2 transform hover:text-purple-500 hover:scale-110"><EditIcon /></button>
                                  <button onClick={() => onDelete(invoice.id)} className="w-5 mr-2 transform hover:text-purple-500 hover:scale-110"><DeleteIcon /></button>
                              </div>
                          </td>
                      </tr>
                  ))}
              </tbody>
          </table>
      </div>
    </div>
  );

const Reports = () => <div><h1 className="text-3xl font-bold">التقارير</h1><p>ميزات التقارير قادمة قريبا.</p></div>;

const Settings = ({ settings, onSave }: { settings: AppData['settings'], onSave: (newSettings: AppData['settings']) => void }) => {
  const [currentSettings, setCurrentSettings] = useState(settings);
  const [isSaved, setIsSaved] = useState(false);

  useEffect(() => {
    setCurrentSettings(settings);
  }, [settings]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type } = e.target;
    setCurrentSettings(prev => ({
      ...prev,
      [name]: type === 'number' ? parseFloat(value) || 0 : value
    }));
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setCurrentSettings(prev => ({ ...prev, companyLogo: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(currentSettings);
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 3000); // Hide message after 3 seconds
  };

  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">الإعدادات</h1>
      <div className="bg-white shadow-md rounded-lg p-8 max-w-4xl">
        <form onSubmit={handleSubmit}>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div>
                    <h2 className="text-xl font-semibold mb-4 border-b pb-2">بيانات الشركة</h2>
                    <div className="mb-4">
                        <label htmlFor="companyName" className="block text-gray-700 text-sm font-bold mb-2">اسم الشركة</label>
                        <input type="text" id="companyName" name="companyName" value={currentSettings.companyName} onChange={handleChange} className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700"/>
                    </div>
                    <div className="mb-4">
                        <label htmlFor="companyAddress" className="block text-gray-700 text-sm font-bold mb-2">العنوان</label>
                        <input type="text" id="companyAddress" name="companyAddress" value={currentSettings.companyAddress} onChange={handleChange} className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700"/>
                    </div>
                    <div className="mb-4">
                        <label htmlFor="companyPhone" className="block text-gray-700 text-sm font-bold mb-2">الهاتف</label>
                        <input type="text" id="companyPhone" name="companyPhone" value={currentSettings.companyPhone} onChange={handleChange} className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700"/>
                    </div>
                    <div className="mb-4">
                        <label htmlFor="vatNumber" className="block text-gray-700 text-sm font-bold mb-2">الرقم الضريبي</label>
                        <input type="text" id="vatNumber" name="vatNumber" value={currentSettings.vatNumber} onChange={handleChange} className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700"/>
                    </div>
                     <div className="mb-4">
                        <label htmlFor="companyLogo" className="block text-gray-700 text-sm font-bold mb-2">شعار الشركة</label>
                        <input type="file" id="companyLogo" accept="image/*" onChange={handleImageUpload} className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"/>
                        {currentSettings.companyLogo && <img src={currentSettings.companyLogo} alt="شعار الشركة" className="mt-4 max-h-24 border p-2 rounded" />}
                    </div>
                </div>
                <div>
                    <h2 className="text-xl font-semibold mb-4 border-b pb-2">إعدادات النظام</h2>
                    <div className="mb-4">
                        <label htmlFor="taxRate" className="block text-gray-700 text-sm font-bold mb-2">معدل الضريبة (%)</label>
                        <input type="number" id="taxRate" name="taxRate" value={currentSettings.taxRate} onChange={handleChange} className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700" step="0.1" min="0" />
                    </div>
                    <div className="mb-4">
                        <label htmlFor="pointsPerCurrency" className="block text-gray-700 text-sm font-bold mb-2">نقاط لكل وحدة عملة</label>
                        <input type="number" id="pointsPerCurrency" name="pointsPerCurrency" value={currentSettings.pointsPerCurrency} onChange={handleChange} className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700" step="0.1" min="0" />
                        <p className="text-xs text-gray-500 mt-1">عدد النقاط التي يكتسبها العميل مقابل كل وحدة عملة يتم إنفاقها.</p>
                    </div>
                    <div className="mb-4">
                        <label htmlFor="currencySymbol" className="block text-gray-700 text-sm font-bold mb-2">رمز العملة</label>
                        <input type="text" id="currencySymbol" name="currencySymbol" value={currentSettings.currencySymbol} onChange={handleChange} className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700" />
                    </div>
                    <div className="mb-4">
                        <label htmlFor="lowStockThreshold" className="block text-gray-700 text-sm font-bold mb-2">حد المخزون المنخفض</label>
                        <input type="number" id="lowStockThreshold" name="lowStockThreshold" value={currentSettings.lowStockThreshold} onChange={handleChange} className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700" min="0" />
                        <p className="text-xs text-gray-500 mt-1">سيتم إعلامك عندما تصل كمية المنتج إلى هذا الحد.</p>
                    </div>
                </div>
            </div>
            <div className="mt-8 flex items-center justify-start">
                <button type="submit" className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline">
                    حفظ الإعدادات
                </button>
                {isSaved && <span className="text-green-500 font-semibold mr-4">تم الحفظ بنجاح!</span>}
            </div>
        </form>
      </div>
    </div>
  );
};


const navItems = [
  { name: 'لوحة التحكم', icon: DashboardIcon, view: 'dashboard' },
  { name: 'الفواتير', icon: InvoicingIcon, view: 'invoicing' },
  { name: 'المنتجات', icon: ProductsIcon, view: 'products' },
  { name: 'العملاء', icon: CustomersIcon, view: 'customers' },
  { name: 'التقارير', icon: ReportsIcon, view: 'reports' },
  { name: 'الإعدادات', icon: SettingsIcon, view: 'settings' },
];

type View = 'dashboard' | 'invoicing' | 'products' | 'customers' | 'reports' | 'settings';
type ModalMode = 'create' | 'edit' | 'view' | 'closed';

const App = () => {
  const [data, setData] = useLocalStorage<AppData>('pos-data', initialData);
  const [activeView, setActiveView] = useState<View>('dashboard');
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [modalMode, setModalMode] = useState<ModalMode>('closed');
  const [currentInvoice, setCurrentInvoice] = useState<Invoice | null>(null);

  const handleSaveSettings = (newSettings: AppData['settings']) => {
    setData(prevData => ({ ...prevData, settings: newSettings }));
  };

  const handleLogin = (username, password) => {
    if (username === 'admin' && password === 'admin') {
      setIsAuthenticated(true);
      return true;
    }
    return false;
  };
  
  const handleLogout = () => {
      setIsAuthenticated(false);
  };

  const handleOpenModal = (mode: ModalMode, invoice: Invoice | null = null) => {
    setModalMode(mode);
    setCurrentInvoice(invoice);
  };

  const handleCloseModal = () => {
    setModalMode('closed');
    setCurrentInvoice(null);
  };
  
  const handleSaveInvoice = (invoice: Invoice) => {
    setData(prevData => {
        const newData = { ...prevData };
        const originalInvoice = prevData.invoices.find(inv => inv.id === invoice.id);
        
        // Adjust stock levels
        const newProducts = [...prevData.products];

        // Re-stock items from original invoice if editing
        if(originalInvoice) {
            originalInvoice.items.forEach(item => {
                const productIndex = newProducts.findIndex(p => p.id === item.productId);
                if (productIndex !== -1) {
                    newProducts[productIndex].quantity += item.quantity;
                }
            });
        }
        
        // De-stock items from new/updated invoice
        invoice.items.forEach(item => {
            const productIndex = newProducts.findIndex(p => p.id === item.productId);
            if (productIndex !== -1) {
                newProducts[productIndex].quantity -= item.quantity;
            }
        });
        
        newData.products = newProducts;
        
        // Add or update invoice
        if (originalInvoice) {
            const invoiceIndex = newData.invoices.findIndex(inv => inv.id === invoice.id);
            newData.invoices[invoiceIndex] = invoice;
        } else {
            newData.invoices.push(invoice);
        }

        // Adjust customer points
        if(invoice.customerId) {
            const customerIndex = newData.customers.findIndex(c => c.id === invoice.customerId);
            if(customerIndex !== -1) {
                 const pointsEarned = Math.floor(invoice.total * newData.settings.pointsPerCurrency);
                 // Simple point addition, could be more complex
                 newData.customers[customerIndex].points += pointsEarned;
            }
        }
        
        return newData;
    });
    handleCloseModal();
  };
  
  const handleDeleteInvoice = (invoiceId: string) => {
      if (window.confirm('هل أنت متأكد من حذف هذه الفاتورة؟ لا يمكن التراجع عن هذا الإجراء.')) {
          setData(prevData => {
              const invoiceToDelete = prevData.invoices.find(inv => inv.id === invoiceId);
              if (!invoiceToDelete) return prevData;

              const newProducts = [...prevData.products];
              // Re-stock items from the deleted invoice
              invoiceToDelete.items.forEach(item => {
                  const productIndex = newProducts.findIndex(p => p.id === item.productId);
                  if (productIndex !== -1) {
                      newProducts[productIndex].quantity += item.quantity;
                  }
              });

              return {
                  ...prevData,
                  products: newProducts,
                  invoices: prevData.invoices.filter(inv => inv.id !== invoiceId)
              };
          });
      }
  };

  if (!isAuthenticated) {
    return <Login onLogin={handleLogin} />;
  }

  const renderContent = () => {
    switch (activeView) {
      case 'dashboard':
        return <Dashboard data={data} />;
      case 'invoicing':
        return <Invoicing 
                    invoices={data.invoices} 
                    settings={data.settings}
                    onAddNew={() => handleOpenModal('create')}
                    onEdit={(invoice) => handleOpenModal('edit', invoice)}
                    onView={(invoice) => handleOpenModal('view', invoice)}
                    onDelete={handleDeleteInvoice}
                />;
      case 'products':
        return <Products products={data.products} settings={data.settings} />;
      case 'customers':
        return <Customers customers={data.customers} />;
      case 'reports':
        return <Reports />;
      case 'settings':
        return <Settings settings={data.settings} onSave={handleSaveSettings} />;
      default:
        return <Dashboard data={data} />;
    }
  };

  return (
    <div className="flex h-screen bg-gray-100 font-sans">
      <aside className="w-64 bg-gray-800 text-white flex flex-col no-print">
        <div className="p-4 text-2xl font-bold border-b border-gray-700 text-center">
          نظام نقاط البيع
        </div>
        <nav className="flex-1 p-2">
          <ul>
            {navItems.map(item => (
              <li key={item.view}>
                <button
                  onClick={() => setActiveView(item.view as View)}
                  className={`flex items-center w-full p-3 my-1 rounded-lg transition-colors duration-200 ${
                    activeView === item.view ? 'bg-gray-700' : 'hover:bg-gray-700'
                  }`}
                >
                  <item.icon />
                  <span className="mr-4">{item.name}</span>
                </button>
              </li>
            ))}
          </ul>
        </nav>
        <div className="p-2 border-t border-gray-700">
            <button
                onClick={handleLogout}
                className="flex items-center w-full p-3 my-1 rounded-lg transition-colors duration-200 text-red-400 hover:bg-red-500 hover:text-white"
            >
                <LogoutIcon />
                <span className="mr-4">تسجيل الخروج</span>
            </button>
        </div>
      </aside>
      <main className="flex-1 p-8 overflow-y-auto">
        {renderContent()}
        {modalMode !== 'closed' && (
            <InvoiceModal 
                isOpen={modalMode !== 'closed'}
                onClose={handleCloseModal}
                mode={modalMode}
                invoiceData={currentInvoice}
                customers={data.customers}
                products={data.products}
                settings={data.settings}
                onSave={handleSaveInvoice}
                lastInvoiceNumber={data.invoices.length > 0 ? Math.max(...data.invoices.map(i => i.invoiceNumber)) : 1000}
            />
        )}
      </main>
    </div>
  );
};

export default App;
