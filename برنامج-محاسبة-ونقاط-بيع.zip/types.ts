export interface Product {
  id: string;
  name: string;
  category: string;
  price: number;
  cost: number;
  quantity: number;
  barcode: string;
  commission: number;
}

export interface Customer {
  id:string;
  name: string;
  phone: string;
  email: string;
  points: number;
}

export interface InvoiceItem {
  productId: string;
  name: string;
  quantity: number;
  price: number;
}

export interface Invoice {
  id: string;
  invoiceNumber: number;
  customerId?: string;
  customerName: string;
  items: InvoiceItem[];
  subtotal: number;
  tax: number;
  discount: number;
  total: number;
  date: string;
}

export type AppData = {
  products: Product[];
  customers: Customer[];
  invoices: Invoice[];
  settings: {
    taxRate: number;
    pointsPerCurrency: number;
    currencySymbol: string;
    lowStockThreshold: number;
    companyName: string;
    companyAddress: string;
    companyPhone: string;
    vatNumber: string;
    companyLogo: string; // base64 encoded image
  };
};
